
// Flutter app: Specialty Powder Coating
// Created by Mohammed Wasel Quraishi

import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'dart:io';
import 'package:path_provider/path_provider.dart';

void main() {
  runApp(SpecialtyPowderApp());
}

class SpecialtyPowderApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Specialty Powder Coating',
      theme: ThemeData.light(),
      darkTheme: ThemeData.dark(),
      themeMode: ThemeMode.system,
      home: LoginPage(),
    );
  }
}

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final pinController = TextEditingController();
  final approvedPins = ['1234', '5678']; // Add Wasel-approved PINs here

  void login() {
    if (approvedPins.contains(pinController.text)) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => ScanPage(userPin: pinController.text)),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Invalid PIN')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/background.jpg'), // Add your uploaded background here
            fit: BoxFit.cover,
          ),
        ),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                TextField(
                  controller: pinController,
                  decoration: InputDecoration(labelText: 'Enter 4-digit PIN'),
                  keyboardType: TextInputType.number,
                  maxLength: 4,
                  obscureText: true,
                ),
                ElevatedButton(onPressed: login, child: Text('Login')),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class ScanPage extends StatefulWidget {
  final String userPin;
  ScanPage({required this.userPin});

  @override
  _ScanPageState createState() => _ScanPageState();
}

class _ScanPageState extends State<ScanPage> {
  List<String> scanLogs = [];

  void onDetect(Barcode barcode, MobileScannerArguments? args) {
    final String code = barcode.rawValue ?? "";
    final String log = '${DateTime.now()} - $code';
    setState(() {
      scanLogs.add(log);
    });
  }

  Future<void> generatePDF() async {
    final pdf = pw.Document();
    pdf.addPage(
      pw.Page(
        build: (pw.Context context) => pw.ListView.builder(
          itemCount: scanLogs.length,
          itemBuilder: (_, i) => pw.Text(scanLogs[i]),
        ),
      ),
    );

    final output = await getTemporaryDirectory();
    final file = File("${output.path}/scan_report.pdf");
    await file.writeAsBytes(await pdf.save());
    await Printing.sharePdf(bytes: await pdf.save(), filename: 'scan_report.pdf');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Scan & Track')),
      body: Column(
        children: [
          Expanded(
            child: MobileScanner(onDetect: onDetect),
          ),
          ElevatedButton(
            onPressed: generatePDF,
            child: Text('Download/Share PDF Report'),
          ),
        ],
      ),
    );
  }
}
